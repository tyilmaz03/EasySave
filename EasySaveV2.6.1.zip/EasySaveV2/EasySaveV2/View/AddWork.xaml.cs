﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EasySaveV2;

namespace EasySaveV2.View
{
    /// <summary>
    /// Logique d'interaction pour AddWork.xaml
    /// </summary>
    public partial class AddWork : Window
    {

        WorkType workType;
        public AddWork()
        {
            InitializeComponent();
            SaveButton.Content = Lang.LangText[11];
            NameLabel.Content = Lang.LangText[4];
            SrcLabel.Content = Lang.LangText[5];
            DestLabel.Content = Lang.LangText[7];
            TypeLabel.Content = Lang.LangText[8];
            Complete.Content = Lang.LangText[9];
            Differential.Content = Lang.LangText[10];

        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (Complete.IsChecked == true)
                workType = WorkType.complete;
            else
                workType = WorkType.differential;

            if (Directory.Exists(SrcPath.Text))
            {
                if (!Directory.Exists(DestPath.Text))
                    Directory.CreateDirectory(DestPath.Text);

                WorkAction.CreateWork(WorkName.Text, SrcPath.Text, DestPath.Text, workType);
                MessageBox.Show(Lang.LangText[22]);
                this.Close();
                App.Current.MainWindow.Show();
            }
            else
            {
                MessageBox.Show(Lang.LangText[6]);
            }
        }

        private void GetBackBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            App.Current.MainWindow.Show();
        }
    }
}
