﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EasySaveV2;

namespace EasySaveV2.View
{
    /// <summary>
    /// Logique d'interaction pour DeleteWork.xaml
    /// </summary>
    public partial class DeleteWork : Window
    {
        public DeleteWork()
        {
            InitializeComponent();
            DataContext = new Data();
            gridView.Columns[0].Header = Lang.LangText[12];
            gridView.Columns[1].Header = Lang.LangText[13];
            gridView.Columns[2].Header = Lang.LangText[14];
            gridView.Columns[3].Header = Lang.LangText[15];
            DeleteBtn.Content = Lang.LangText[16];
        }

        private void DeleteBtn_Click(object sender, RoutedEventArgs e)
        {
            WorkAction.DeleteWork(lvSaves);
        }

        private void GetBackBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            App.Current.MainWindow.Show();
        }
    }
}
