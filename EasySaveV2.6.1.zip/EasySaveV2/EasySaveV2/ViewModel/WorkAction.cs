﻿using EasySaveV2.View;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace EasySaveV2
{
    public class WorkAction
    {
        // Create a new work
        public static void CreateWork(string workName,string srcPath,string destPath,WorkType workType)
        {
            var work = new Work(workName, srcPath, destPath, workType);
            work.CreationTime = DateTime.Now.ToString();
            work.WorkState = WorkState.inactive;
            work.FilesToCopyAndDirSize();
            Data.WorkList.Add(work);
            Data.SaveData();

        }

        // Delete an existing work
        public static void DeleteWork(ListView lvSaves)
        {
            if (lvSaves.SelectedItem != null)
            {
                Data.WorkList.Remove(lvSaves.SelectedItem as Work);
                Data.SaveData();
            }
        }

        // Execute a work
        public static async Task ExecuteOne(int workNb)
        {

                Task thread2 = Task.Factory.StartNew(() => JobAppRunning.IsJobAppRunning());
                Task.WaitAll(thread2);
                if (JobAppRunning.IsRunning == false)
                {
                    MessageBoxResult result = MessageBox.Show(Lang.LangText[21], "Confirmation", MessageBoxButton.YesNo);
                    if (result == MessageBoxResult.Yes)
                    {
                        Encryption.Encrypt = true;
                        EncryptionKey encryptionKey = new EncryptionKey();
                        encryptionKey.ShowDialog();
                    }
                    Save.CreateDirectories(workNb);
                    Save.CopyFiles(workNb);
                }
                else
                {
                    MessageBox.Show(Lang.LangText[23]);
                }
        }

        // Execute all works sequentially
        public static void ExecuteAll()
        {
            MessageBoxResult result = MessageBox.Show(Lang.LangText[21], "Confirmation", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
            {
                Encryption.Encrypt = true;
                EncryptionKey encryptionKey = new EncryptionKey();
                encryptionKey.ShowDialog();
            }
            for (int i = 0; i < Data.WorkList.Count; i++)
            {
                Thread th = new Thread(ExecutAll);
                th.Start(i);

            }
        }

        public static void ExecutAll(object arg)
        {
            MessageBox.Show(arg.ToString());
            Task thread2 = Task.Factory.StartNew(() => JobAppRunning.IsJobAppRunning());
            Task.WaitAll(thread2);
            if (JobAppRunning.IsRunning == false)
            {
                Save.CreateDirectories((int)arg);
                Save.CopyFiles((int)arg);
            }
            else
            {
                MessageBox.Show(Lang.LangText[23]);
            }

        }
    }
}
