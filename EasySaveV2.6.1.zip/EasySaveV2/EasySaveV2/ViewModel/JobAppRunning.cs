﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace EasySaveV2
{
    public class JobAppRunning
    {
        public static bool IsRunning { get; set; }

        public static void IsJobAppRunning()
        {
            Process[] processes = Process.GetProcessesByName("winword");
                processes = Process.GetProcessesByName("winword");
                if (processes.Length == 0)
                {
                    IsRunning = false;
                }
                else
                {
                    IsRunning = true;
                }
        }
    }
}
