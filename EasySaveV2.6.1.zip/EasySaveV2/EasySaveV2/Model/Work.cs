﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using EasySaveV2;
using EasySaveV2.View;

namespace EasySaveV2
{
    public class Work : INotifyPropertyChanged
    {

        public string Name { get; set; }
        public string SrcPath { get; set; }
        public string DestPath { get; set; }
        public string CreationTime { get; set; }
        public WorkState WorkState { get; set; }
        public WorkType Type { get; set; }
        public int NbFilesLeftToDo { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void Notify([CallerMemberName] string p = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(p));

        private double _progression;
        public double Progression { get { return _progression; } set { _progression = value; Notify(); } }

        public int TotalFilesToCopy { get; set; }
        public long TotalDirSize { get; set; }


        public Work(string _name, string _srcPath, string _destPath, WorkType _type)
        {
            Name = _name;
            SrcPath = _srcPath;
            DestPath = _destPath;
            CreationTime = "";
            WorkState = WorkState.undefined;
            Type = _type;
            TotalFilesToCopy = 0;
            TotalDirSize = 0;

        }

        public void FilesToCopyAndDirSize()
        {
            TotalFilesToCopy = 0;
            foreach (var file in Directory.GetFiles(SrcPath, "*.*", SearchOption.AllDirectories))
            {
                var fileInfo = new FileInfo(file);
                var destFile = file.Replace(SrcPath, DestPath);
                TotalDirSize += fileInfo.Length;
                if (Type == WorkType.complete)
                    TotalFilesToCopy += 1;

                else if (!File.Exists(destFile) || (File.GetLastWriteTime(file) != File.GetLastWriteTime(destFile)))
                    TotalFilesToCopy += 1;
            }
        }

    }

    public enum WorkType
    {
        undefined,
        complete,
        differential
    }

    public enum WorkState
    {
        undefined,
        inactive,
        active,
        ended
    }
}
