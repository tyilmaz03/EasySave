﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.IO;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace EasySaveV2
{
    public class SaveInfo 
    {
        public static long FileTransferTime { get; set; }
        public static string FileSrcPath { get; set; }
        public static string FileDestPath { get; set; }
        public static long FileSize { get; set; }
        public static double EncryptionTime { get; set; }


        
        // Set variables of logs during copy
        public static void Start(Work work, Stopwatch watch, string src, string dest)
        {
            SaveInfo saveInfo = new SaveInfo();
            var fi = new FileInfo(src);
            FileSize = fi.Length;
            FileTransferTime = watch.ElapsedMilliseconds;
            FileSrcPath = Path.GetFullPath(src);
            FileDestPath = Path.GetFullPath(dest);
            work.NbFilesLeftToDo--;
            work.Progression = (double)(100 - (((double)(work.NbFilesLeftToDo) / (work.TotalFilesToCopy)) * 100));

        }
    }
}
